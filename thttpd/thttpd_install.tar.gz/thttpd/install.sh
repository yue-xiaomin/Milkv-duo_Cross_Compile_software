#!/bin/sh

echo "install thttpd..."
cp -a bin/* /usr/bin
cp -a etc/* /etc
cp -a www/* /var/www
echo "done!"
