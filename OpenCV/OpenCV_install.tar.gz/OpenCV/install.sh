#!/bin/sh

echo "OpenCV lib install"
cp -a lib/* /usr/lib
echo "done!"
