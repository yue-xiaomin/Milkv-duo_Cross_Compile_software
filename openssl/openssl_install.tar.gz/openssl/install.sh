#!/bin/sh

echo "install openssl..."
cp -a bin/* /usr/bin
cp -a lib/* /usr/lib
echo "done!"
