#!/bin/sh

echo "install libev lib..."
cp -a lib/* /usr/lib
echo "done!"
