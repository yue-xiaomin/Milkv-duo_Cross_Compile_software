#!/bin/sh

echo "install cJSON lib..."
cp -a lib/* /usr/lib
echo "done!"
