#!/bin/sh

echo "install sqlite3..."
cp -a bin/* /usr/bin
cp -a lib/* /usr/lib
echo "done!"
