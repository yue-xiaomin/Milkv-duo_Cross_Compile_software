#!/bin/sh

echo "install mqtt(mosquitto) server..."
cp -a bin/* /usr/bin
cp -a lib/* /usr/lib
if [ ! -d "/etc/mosquitto" ];then 
    mkdir /etc/mosquitto
fi
cp -a etc/mosquitto/* /etc/mosquitto

echo "done!"
